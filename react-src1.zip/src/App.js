import logo from './logo.svg';
import './App.css';
import Comp1 from './Components/Comp1';
import Comp2 from './Components/Comp2';
import Comp3 from './Components/Comp3';
import Counter from './Components/Counter';
import Products from './Components/Products';
import DeliveryComp from './Components/DeliveryComp';
import DeliveryClassComp from './Components/DeliveryClass';
import { useState } from 'react';
import Parent from './Components/Parent';
import ParentNew from './Components/ParentNew';
import OrginalComp from './Components/OrginalComp';
import CityList from './Components/CityList';
import HookDemo from './Components/HookDemo';
import { createContext } from 'react';
import UseRefDemo from './Components/useRefDemo';

export let Globalinfo=createContext()

function App() {
  let animals=["lion","tiger","deer","hippo","Elephant"]
  const [cart, setCart]=useState([])
   console.log(cart)
  return (
    
    <div className="App">
      <Globalinfo.Provider value={cart}>
        <UseRefDemo/>
      </Globalinfo.Provider>
    </div>
  );
}

export default App;
