import React, { useState } from 'react';
import { BaseCounter } from './BaseCounter';

function CityList(props) {
    const [citylist,setCityList]=useState(["mumbai","delhi","goa","chennai"])
    return (
        <div>
            <button onClick={props.inc} >+</button>
            <h3>{citylist[props.index]}</h3>
            <button onClick={props.dec}>-</button>
        </div>
    );
}

export default BaseCounter(CityList);