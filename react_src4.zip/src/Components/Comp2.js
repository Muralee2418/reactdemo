import React from "react";
function Comp2(){

    return(
        <div>
            <h2>Hello everyone</h2>
        </div>
    )
}

export default Comp2